using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Coin_Count
{
    [Activity(Label = "Activit2")]
    public class Activit2 : Activity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.layout2);

			Button btn4 = FindViewById<Button>(Resource.Id.gobacktomain1);
			btn4.Click += delegate { StartActivity(typeof(MainActivity)); };



            // Create your application here
        }
    }
}