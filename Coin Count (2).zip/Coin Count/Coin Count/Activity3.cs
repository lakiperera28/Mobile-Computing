using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Coin_Count
{
    [Activity(Label = "Activity3")]
    public class Activity3 : Activity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.layout3);

			Button btn5 = FindViewById<Button>(Resource.Id.gobacktomain2);
			btn5.Click += delegate { StartActivity(typeof(MainActivity)); };

            // Create your application here
        }
    }
}