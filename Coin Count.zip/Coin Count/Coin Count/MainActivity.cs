﻿using Android.App;
using Android.Widget;
using Android.OS;

namespace Coin_Count
{
    [Activity(Label = "Coin_Count", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
			SetContentView(Resource.Layout.Main);


            Button btn1 = FindViewById<Button>(Resource.Id.gotopage2);
            btn1.Click += delegate { StartActivity(typeof(Activit2)); };


            Button btn2 = FindViewById<Button>(Resource.Id.gotopage3);
            btn2.Click += delegate { StartActivity(typeof(Activity3)); };


            Button btn3 = FindViewById<Button>(Resource.Id.gotopage4);
            btn3.Click += delegate { StartActivity(typeof(Activity4)); };




            // Set our view from the "main" layout resource
            // SetContentView (Resource.Layout.Main);
        }
    }
}

